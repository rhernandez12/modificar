/*
SQLyog Community
MySQL - 10.0.34-MariaDB-0ubuntu0.16.04.1 : Database - catalogos
*********************************************************************
*/

/*!40101 SET NAMES utf8 */;

/*!40101 SET SQL_MODE=''*/;

/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;
USE `ccm1_temporal`;

LOAD DATA CONCURRENT INFILE '/modificaciones/ccm1_temporal_casa_down_util_sw.csv' IGNORE INTO TABLE ccm1_temporal.cmts_casa_down_util_sw FIELDS TERMINATED by ',' LINES TERMINATED by '\r\n' IGNORE 1 LINES;




